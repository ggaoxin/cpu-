import type { InputMode } from '../types'

export class ApiRequestError extends Error {
  status: number
  details: unknown

  constructor(message: string, status: number, details?: unknown) {
    super(message)
    this.name = 'ApiRequestError'
    this.status = status
    this.details = details
  }
}

// 构建期 base（vite --base=/dma/sem/ 时为 '/dma/sem'，默认为 ''）。
// 公网网关只转发带该前缀的路径，运行时 fetch 与页面跳转都必须带上。
const basePath = String(import.meta.env.BASE_URL || '/').replace(/\/+$/, '')

export function apiUrl(endpoint: string) {
  const configured = String(import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '')
  if (!configured || configured === '/api') return `${basePath}${endpoint}`
  if (/^https?:\/\//i.test(configured)) return `${configured}${endpoint}`
  return `${basePath}${configured}${endpoint}`.replace(/\/+/g, '/')
}

export function appPath(path: string) {
  return `${basePath}${path}`
}

function jsonSafeValue(value: unknown): unknown {
  if (value instanceof File) return null
  if (Array.isArray(value)) return value.map(jsonSafeValue)
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, child]) => [key, jsonSafeValue(child)]))
  }
  return value
}

function appendFormValue(form: FormData, key: string, value: unknown) {
  if (value === undefined || value === null) return
  if (value instanceof File) {
    form.append(key, value, value.name)
    return
  }
  if (Array.isArray(value) && value.every(item => item instanceof File)) {
    value.forEach(item => form.append(key, item as File, (item as File).name))
    return
  }
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>
    Object.entries(record).forEach(([nestedKey, child]) => {
      if (child instanceof File) form.append(`${key}__${nestedKey}`, child, child.name)
    })
    form.append(key, JSON.stringify(jsonSafeValue(value)))
    return
  }
  if (Array.isArray(value)) {
    form.append(key, JSON.stringify(jsonSafeValue(value)))
    return
  }
  form.append(key, String(value))
}

function containsFile(value: unknown): boolean {
  if (value instanceof File) return true
  if (Array.isArray(value)) return value.some(containsFile)
  return Boolean(value && typeof value === 'object' && Object.values(value as Record<string, unknown>).some(containsFile))
}

// ---- API Key（后端开启 API_AUTH_ENABLED 时生效；默认关闭零感知）----
// 401 时弹窗索取密钥存 localStorage，重放一次请求
function storedApiKey(): string {
  return localStorage.getItem('x-api-key') || ''
}

function promptApiKey(): string {
  const key = window.prompt('本系统已开启接口鉴权，请输入 API Key：', storedApiKey()) || ''
  if (key) localStorage.setItem('x-api-key', key)
  return key
}

async function fetchWithApiKey(url: string, init: RequestInit): Promise<Response> {
  const key = storedApiKey()
  if (key) (init.headers as Record<string, string>)['X-API-Key'] = key
  const response = await fetch(url, init)
  if (response.status === 401 && !init.headers?.['X-API-Key']) {
    const retryKey = promptApiKey()
    if (retryKey) {
      ;(init.headers as Record<string, string>)['X-API-Key'] = retryKey
      return fetch(url, init)
    }
  }
  return response
}

async function parseResponse(response: Response) {
  const contentType = response.headers.get('content-type') || ''
  const body = contentType.includes('application/json')
    ? await response.json()
    : { message: await response.text() }
  if (!response.ok || Number(body?.code || 0) !== 0) {
    // 失败原因优先级：detail（FastAPI 422）> error_summary（业务失败的真实原因，
    // 如语言不匹配/解析失败——message 只是状态字符串 "failed"，对用户无信息量）
    // > 逐条 results 里首个带 error 的记录（无汇总时的兜底）> message > HTTP 状态
    const data = body?.data
    const firstItemError = Array.isArray(data?.results)
      ? (data.results as Array<Record<string, unknown>>).find(item => item && item.error)?.error
      : null
    const detail = body?.detail
      || data?.error_summary
      || firstItemError
      || body?.message
      || `请求失败（HTTP ${response.status}）`
    throw new ApiRequestError(typeof detail === 'string' ? detail : JSON.stringify(detail), response.status, body)
  }
  return body
}

export async function executeToolRequest(
  endpoint: string,
  mode: InputMode,
  payload: Record<string, unknown>,
  opts?: { headers?: Record<string, string> },
) {
  const fileMode = mode === 'file' || mode === 'batch' || containsFile(payload)
  const init: RequestInit = {
    method: 'POST',
    headers: { Accept: 'application/json', ...(opts?.headers || {}) },
  }
  if (fileMode) {
    const form = new FormData()
    Object.entries(payload).forEach(([key, value]) => appendFormValue(form, key, value))
    init.body = form
  } else {
    ;(init.headers as Record<string, string>)['Content-Type'] = 'application/json'
    init.body = JSON.stringify(jsonSafeValue(payload))
  }
  // 超时保护:深度聚类/批量任务可能运行数分钟,给 15 分钟硬超时,
  // 避免 >50MB 上传或后端阻塞时前端 fetch 永久挂起、页面无法恢复
  init.signal = AbortSignal.timeout(15 * 60 * 1000)
  try {
    return parseResponse(await fetchWithApiKey(apiUrl(endpoint), init))
  } catch (error) {
    if (error instanceof DOMException && error.name === 'TimeoutError') {
      throw new ApiRequestError('请求超时（15 分钟）：任务未在时限内完成，请减少批量规模后重试', 408, null)
    }
    throw error
  }
}

export async function parseCitationMetadata(entriesText: string) {
  const response = await fetchWithApiKey(apiUrl('/api/v1/citation-metadata/parse'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ entries_text: entriesText }),
  })
  return parseResponse(response)
}

export async function listSemanticResources() {
  const response = await fetchWithApiKey(apiUrl('/api/v1/semantic-resources?status=current&limit=500'), {
    headers: { Accept: 'application/json' },
  })
  return parseResponse(response)
}

export async function listClusterCollections() {
  // 聚类标签生成任务的簇文献集（结构化综述"指定文献集"数据源）。
  // 直接按任务时间倒序全量返回，用户从下拉框直接选择（无主题相似度过滤）
  const query = new URLSearchParams({ limit: '200' })
  return parseResponse(await fetchWithApiKey(apiUrl(`/api/v1/collections/cluster-sets?${query}`), { headers: { Accept: 'application/json' } }))
}

export async function listDocumentCollections(topic?: string) {
  const query = new URLSearchParams({ limit: '200' })
  if (topic && topic.trim()) {
    query.set('topic', topic.trim())
    query.set('threshold', '0.3')
  }
  return parseResponse(await fetchWithApiKey(apiUrl(`/api/v1/collections?${query}`), { headers: { Accept: 'application/json' } }))
}

export async function listCompatibleHistory(downstreamTool: string, upstreamType: string) {
  const query = new URLSearchParams({ downstream_tool: downstreamTool, upstream_type: upstreamType, limit: '200' })
  return parseResponse(await fetchWithApiKey(apiUrl(`/api/v1/history/compatible?${query}`), { headers: { Accept: 'application/json' } }))
}

export async function listDictionaries() {
  return parseResponse(await fetchWithApiKey(apiUrl('/api/v1/dictionaries?limit=200'), { headers: { Accept: 'application/json' } }))
}

export async function saveDictionary(payload: Record<string, unknown>) {
  return parseResponse(await fetchWithApiKey(apiUrl('/api/v1/dictionaries'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(payload),
  }))
}

export async function uploadSemanticResource(file: File, resourceKey: string) {
  const form = new FormData()
  form.append('resource_key', resourceKey)
  form.append('upload', file)
  return parseResponse(await fetchWithApiKey(apiUrl('/api/v1/semantic-resources/upload'), {
    method: 'POST',
    headers: { Accept: 'application/json' },
    body: form,
  }))
}

// CLC 索引构建进度（轮询用，轻量 GET——不重复触发构建）
export async function getIndexStatus(storageUri: string) {
  const q = new URLSearchParams({ storage_uri: storageUri })
  return parseResponse(await fetchWithApiKey(apiUrl(`/api/v1/semantic-resources/index-status?${q}`), {
    headers: { Accept: 'application/json' },
  }))
}

// 资源预检（选文件即校验）：加载/解析/归一/大模型重构在参数录入阶段完成，
// 点击在线测试时只跑功能。返回 {valid, rows, normalized_by, error, note}
export async function validateSemanticResource(file: File, resourceKey: string) {
  const form = new FormData()
  form.append('resource_key', resourceKey)
  form.append('upload', file)
  return parseResponse(await fetchWithApiKey(apiUrl('/api/v1/semantic-resources/validate'), {
    method: 'POST',
    headers: { Accept: 'application/json' },
    body: form,
  }))
}

